// Copyright 2010 The draw2d Authors. All rights reserved.
// created: 13/12/2010 by Laurent Le Goff

// The package draw2d provide a Graphic Context that can draw vectorial figure on surface.
package draw2d
